/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F57Q43
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above
        MPLAB 	          :  MPLAB X 6.00	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set moistureIn aliases
#define moistureIn_TRIS                 TRISAbits.TRISA0
#define moistureIn_LAT                  LATAbits.LATA0
#define moistureIn_PORT                 PORTAbits.RA0
#define moistureIn_WPU                  WPUAbits.WPUA0
#define moistureIn_OD                   ODCONAbits.ODCA0
#define moistureIn_ANS                  ANSELAbits.ANSELA0
#define moistureIn_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define moistureIn_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define moistureIn_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define moistureIn_GetValue()           PORTAbits.RA0
#define moistureIn_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define moistureIn_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define moistureIn_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define moistureIn_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define moistureIn_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define moistureIn_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define moistureIn_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define moistureIn_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA2 procedures
#define RA2_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define RA2_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define RA2_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define RA2_GetValue()              PORTAbits.RA2
#define RA2_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define RA2_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define RA2_SetPullup()             do { WPUAbits.WPUA2 = 1; } while(0)
#define RA2_ResetPullup()           do { WPUAbits.WPUA2 = 0; } while(0)
#define RA2_SetAnalogMode()         do { ANSELAbits.ANSELA2 = 1; } while(0)
#define RA2_SetDigitalMode()        do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set process aliases
#define process_TRIS                 TRISBbits.TRISB0
#define process_LAT                  LATBbits.LATB0
#define process_PORT                 PORTBbits.RB0
#define process_WPU                  WPUBbits.WPUB0
#define process_OD                   ODCONBbits.ODCB0
#define process_ANS                  ANSELBbits.ANSELB0
#define process_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define process_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define process_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define process_GetValue()           PORTBbits.RB0
#define process_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define process_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define process_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define process_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define process_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define process_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define process_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define process_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set move_r aliases
#define move_r_TRIS                 TRISBbits.TRISB5
#define move_r_LAT                  LATBbits.LATB5
#define move_r_PORT                 PORTBbits.RB5
#define move_r_WPU                  WPUBbits.WPUB5
#define move_r_OD                   ODCONBbits.ODCB5
#define move_r_ANS                  ANSELBbits.ANSELB5
#define move_r_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define move_r_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define move_r_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define move_r_GetValue()           PORTBbits.RB5
#define move_r_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define move_r_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define move_r_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define move_r_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define move_r_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define move_r_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define move_r_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define move_r_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set request aliases
#define request_TRIS                 TRISBbits.TRISB6
#define request_LAT                  LATBbits.LATB6
#define request_PORT                 PORTBbits.RB6
#define request_WPU                  WPUBbits.WPUB6
#define request_OD                   ODCONBbits.ODCB6
#define request_ANS                  ANSELBbits.ANSELB6
#define request_SetHigh()            do { LATBbits.LATB6 = 1; } while(0)
#define request_SetLow()             do { LATBbits.LATB6 = 0; } while(0)
#define request_Toggle()             do { LATBbits.LATB6 = ~LATBbits.LATB6; } while(0)
#define request_GetValue()           PORTBbits.RB6
#define request_SetDigitalInput()    do { TRISBbits.TRISB6 = 1; } while(0)
#define request_SetDigitalOutput()   do { TRISBbits.TRISB6 = 0; } while(0)
#define request_SetPullup()          do { WPUBbits.WPUB6 = 1; } while(0)
#define request_ResetPullup()        do { WPUBbits.WPUB6 = 0; } while(0)
#define request_SetPushPull()        do { ODCONBbits.ODCB6 = 0; } while(0)
#define request_SetOpenDrain()       do { ODCONBbits.ODCB6 = 1; } while(0)
#define request_SetAnalogMode()      do { ANSELBbits.ANSELB6 = 1; } while(0)
#define request_SetDigitalMode()     do { ANSELBbits.ANSELB6 = 0; } while(0)

// get/set RD1 procedures
#define RD1_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define RD1_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define RD1_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define RD1_GetValue()              PORTDbits.RD1
#define RD1_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define RD1_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define RD1_SetPullup()             do { WPUDbits.WPUD1 = 1; } while(0)
#define RD1_ResetPullup()           do { WPUDbits.WPUD1 = 0; } while(0)
#define RD1_SetAnalogMode()         do { ANSELDbits.ANSELD1 = 1; } while(0)
#define RD1_SetDigitalMode()        do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set move_f aliases
#define move_f_TRIS                 TRISDbits.TRISD5
#define move_f_LAT                  LATDbits.LATD5
#define move_f_PORT                 PORTDbits.RD5
#define move_f_WPU                  WPUDbits.WPUD5
#define move_f_OD                   ODCONDbits.ODCD5
#define move_f_ANS                  ANSELDbits.ANSELD5
#define move_f_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define move_f_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define move_f_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define move_f_GetValue()           PORTDbits.RD5
#define move_f_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define move_f_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define move_f_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define move_f_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define move_f_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define move_f_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define move_f_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define move_f_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set limit_r aliases
#define limit_r_TRIS                 TRISDbits.TRISD6
#define limit_r_LAT                  LATDbits.LATD6
#define limit_r_PORT                 PORTDbits.RD6
#define limit_r_WPU                  WPUDbits.WPUD6
#define limit_r_OD                   ODCONDbits.ODCD6
#define limit_r_ANS                  ANSELDbits.ANSELD6
#define limit_r_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define limit_r_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define limit_r_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define limit_r_GetValue()           PORTDbits.RD6
#define limit_r_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define limit_r_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define limit_r_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define limit_r_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define limit_r_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define limit_r_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define limit_r_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define limit_r_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set limit_f aliases
#define limit_f_TRIS                 TRISDbits.TRISD7
#define limit_f_LAT                  LATDbits.LATD7
#define limit_f_PORT                 PORTDbits.RD7
#define limit_f_WPU                  WPUDbits.WPUD7
#define limit_f_OD                   ODCONDbits.ODCD7
#define limit_f_ANS                  ANSELDbits.ANSELD7
#define limit_f_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define limit_f_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define limit_f_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define limit_f_GetValue()           PORTDbits.RD7
#define limit_f_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define limit_f_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define limit_f_SetPullup()          do { WPUDbits.WPUD7 = 1; } while(0)
#define limit_f_ResetPullup()        do { WPUDbits.WPUD7 = 0; } while(0)
#define limit_f_SetPushPull()        do { ODCONDbits.ODCD7 = 0; } while(0)
#define limit_f_SetOpenDrain()       do { ODCONDbits.ODCD7 = 1; } while(0)
#define limit_f_SetAnalogMode()      do { ANSELDbits.ANSELD7 = 1; } while(0)
#define limit_f_SetDigitalMode()     do { ANSELDbits.ANSELD7 = 0; } while(0)

// get/set led aliases
#define led_TRIS                 TRISFbits.TRISF3
#define led_LAT                  LATFbits.LATF3
#define led_PORT                 PORTFbits.RF3
#define led_WPU                  WPUFbits.WPUF3
#define led_OD                   ODCONFbits.ODCF3
#define led_ANS                  ANSELFbits.ANSELF3
#define led_SetHigh()            do { LATFbits.LATF3 = 1; } while(0)
#define led_SetLow()             do { LATFbits.LATF3 = 0; } while(0)
#define led_Toggle()             do { LATFbits.LATF3 = ~LATFbits.LATF3; } while(0)
#define led_GetValue()           PORTFbits.RF3
#define led_SetDigitalInput()    do { TRISFbits.TRISF3 = 1; } while(0)
#define led_SetDigitalOutput()   do { TRISFbits.TRISF3 = 0; } while(0)
#define led_SetPullup()          do { WPUFbits.WPUF3 = 1; } while(0)
#define led_ResetPullup()        do { WPUFbits.WPUF3 = 0; } while(0)
#define led_SetPushPull()        do { ODCONFbits.ODCF3 = 0; } while(0)
#define led_SetOpenDrain()       do { ODCONFbits.ODCF3 = 1; } while(0)
#define led_SetAnalogMode()      do { ANSELFbits.ANSELF3 = 1; } while(0)
#define led_SetDigitalMode()     do { ANSELFbits.ANSELF3 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/